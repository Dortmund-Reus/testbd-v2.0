REQUIRE("Arduino MEGA 2560");

void setup()
{
    TL_Serial.begin(9600);
}

void loop()
{
    TL_Serial.print("LED");
    TL_LED.toggle();
    TL_Time.delayMillis(1000);
}